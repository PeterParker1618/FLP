package com.cg.service;

import java.util.List;
import com.cg.model.Promos;

public interface IPromoService {
	
	int getDiscount(int promoId);
	public void addPromo(Promos promo);
	public List<Promos> getAllPromos();
	public Promos getPromo(String promoCode);
	
}
