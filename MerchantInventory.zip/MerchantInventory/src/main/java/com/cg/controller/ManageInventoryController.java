package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Inventory;
import com.cg.model.Merchant;
import com.cg.model.Promos;
import com.cg.service.InventoryMerchantService;
import com.cg.service.MerchantService;
import com.cg.service.ProductService;
import com.cg.service.PromoService;

@CrossOrigin(origins="http://localhost:4200")
//@CrossOrigin(origins="*")
@RestController
//@RequestMapping("/api/v1")
public class ManageInventoryController {
	
	@Autowired
	ProductService productService;
	@Autowired
	InventoryMerchantService inventoryMerchantService;
	@Autowired
	PromoService promoService;
	@Autowired
	MerchantService merchantService;
	
	Merchant merchant;
	
	//To retrieve list of inventories of a particular merchant
	@RequestMapping("/inventories/{mailId}")
	public ResponseEntity<List<Inventory>> getAllInventories(@PathVariable("mailId") String mailId){
		
		merchant = merchantService.getMerchantByMail(mailId);
		List<Inventory> inventories=inventoryMerchantService.getAllInventories(merchant.getMerchantId());
		System.out.println(inventories);
		return new ResponseEntity<List<Inventory>>(inventories,HttpStatus.OK);
		
	}
	
	
	//To edit a particular inventory of a particular merchant
	@RequestMapping("/editInventories/{mailId}")
	public ResponseEntity<Boolean> editInventory(@RequestBody Inventory inventory, @PathVariable("mailId") String mailId)
	{
		System.out.println(inventory);
		merchant=merchantService.getMerchantByMail(mailId);
		System.out.println("this"+merchant);
		inventory.setMerchant(merchant);
		inventory.setInventoryType("MERCHANT");
		System.out.println(merchant);
		inventoryMerchantService.addNewInventory(inventory);
		productService.editProduct(inventory);
		List<Inventory> inventories=inventoryMerchantService.getAllInventories(merchant.getMerchantId());
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
		
	}
	
	
	//To create an inventory for a particular merchant
	@RequestMapping("/addInventories/{mailId}")
	public ResponseEntity<Boolean> addNewInventory(@RequestBody Inventory inventory, @PathVariable("mailId") String mailId)
	
	{
		System.out.println(inventory);
		merchant=merchantService.getMerchantByMail(mailId);
		System.out.println("this"+merchant);
		inventory.setMerchant(merchant);
		inventory.setInventoryType("MERCHANT");
		System.out.println(merchant);
		inventoryMerchantService.addNewInventory(inventory);
		List<Inventory> inventories=inventoryMerchantService.getAllInventories(merchant.getMerchantId());
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
		
	}
	

	//To delete a particular inventory of a particular merchant
	@RequestMapping(value="/inventories/{inventoryId}")
    public ResponseEntity<Boolean>deleteInventory(@PathVariable("inventoryId")int inventoryId){
		
	   inventoryMerchantService.deleteInventory(inventoryId);
	   return new ResponseEntity(true,HttpStatus.OK);
	   
	}
	
	//To edit a particular inventory of a particular merchant
	@RequestMapping("/inventories")
	public ResponseEntity<List<Inventory>>updateInventory(@RequestBody Inventory inventory){
		
		List<Inventory> inventories=inventoryMerchantService.updateInventory(inventory);	
		return new ResponseEntity<List<Inventory>>(inventories,HttpStatus.OK);
	}
	
	//To create a promo for a particular merchant
	@RequestMapping("/inventories/promo")
	public ResponseEntity<Boolean> addPromo(@RequestBody Promos promo){
		
		promoService.addPromo(promo);
		return new ResponseEntity(true,HttpStatus.OK);
	
	}
	
}
